# JARVIS Android + PC birlikte çalışma

Telefon ve bilgisayardaki JARVIS **aynı hafızayı** paylaşır; telefondan bilgisayara uygulama açtırabilir,
dosya aratabilir, sistem bilgisi alabilir (ve istersen komut çalıştırabilirsin).

> ⚠ Bu Android kodu burada derlenip bir telefonda denenmedi. İlk derlemede küçük hata çıkabilir;
> Android Studio'daki hata mesajını bana yapıştır, düzeltelim.

## Nasıl bağlanıyor?
Telefon ↔ bilgisayar arasında **Tailscale** (ücretsiz, şifreli özel ağ) kullanılır. Router ayarı/port açma yok;
bilgisayar internete doğrudan açılmaz. Köprü yalnızca Tailscale ağından gelen, token'lı isteklere cevap verir.

## 1) Bilgisayar (bir kere)
1. https://tailscale.com adresinden **Tailscale** kur, giriş yap.
2. JARVIS klasöründe `setup.bat` (yeni paketler için), sonra **`ESLESTIR.bat`** → sağ tık → *Yönetici olarak çalıştır*.
3. Ekranda çıkan **PC adresi** (100.x.x.x:8765) ve **Token**'ı bir yere not et. Token şifre gibidir, paylaşma.
4. JARVIS'ı kapatıp yeniden aç (köprü açılışta başlar).
Kapatmak için: `TELEFON_KAPAT.bat`.  Yeni token için: `venv\Scripts\python remote_bridge.py --rotate`.

## 2) Telefon (bir kere)
1. Telefona **Tailscale** kur, **aynı hesapla** giriş yap.
2. Telefonda *Ayarlar > Telefon hakkında > Yapı numarası*'na 7 kere dokun → *Geliştirici seçenekleri* → **USB hata ayıklama** aç.
3. Bilgisayara **Android Studio** kur (developer.android.com/studio). Telefonu USB ile bağla, "izin ver" de.
4. Android Studio → **Open** → bu klasörü (içinde `settings.gradle.kts` olan) seç. "Gradle Sync" bitene kadar bekle (ilk seferde indirme yapar).
5. Üstte telefonunu seçip **▶ Run**. Uygulama telefona kurulur. (APK için: Build > Build APK(s).)


## Android Studio KURMADAN APK almak (GitHub ile, ücretsiz)
1. https://github.com adresinde hesap aç / giriş yap.
2. Sağ üstte **+ → New repository**. Ad: `jarvis-android`, **Private** seç, **Create repository**.
3. Açılan sayfada **uploading an existing file** bağlantısına tıkla. Bu klasörün **içindeki her şeyi**
   (`app`, `gradle`, `build.gradle.kts`, `settings.gradle.kts`, `gradle.properties`, `.gitignore`, `.github` klasörü dahil)
   sürükleyip bırak → **Commit changes**.
   - `.github` klasörü görünmüyorsa: **Add file → Create new file**, ad kutusuna `.github/workflows/build-apk.yml` yaz,
     içine bu klasördeki aynı adlı dosyanın içeriğini yapıştır, **Commit**.
4. Üstteki **Actions** sekmesi → solda **APK derle** → **Run workflow** → yeşil düğme. ~5 dakika bekle.
5. Bitince çalışmaya tıkla, en altta **Artifacts → JARVIS-apk** indir. Zip'in içinde `app-debug.apk` var.
6. APK'yı telefona at (kablo / Drive / Telegram). Telefonda dosyaya dokun → "bilinmeyen kaynaktan kuruluma izin ver" → **Kur**.

Derleme kırmızı (başarısız) olursa: çalışmaya tıkla → hatalı adıma tıkla → kırmızı hata satırlarını bana yapıştır.

## 3) Uygulama ayarları
JARVIS > **AYARLAR**: Gemini API anahtarı, PC adresi, PC token'ı → **KAYDET** → **PC BAĞLANTISINI DENE**.
Sonra büyük düğmeye bas, mikrofon iznini ver, konuş.

## Telefonda neler yapar
Sesli sohbet (Gemini Live) · ortak hafıza · takvim etkinliği (ekran açar, KAYDET'e sen dokunursun) ·
alarm / sayaç · telefondaki uygulamayı açma · PC: uygulama aç, dosya ara, sistem bilgisi, komut.

## Bilerek olmayanlar
- "Hey Jarvis" ile arka planda uyanma yok (uygulama açıkken çalışır).
- Telefondan PC'de dosya **okuma/yazma/silme** ve WhatsApp yok (güvenlik için).
- PC'deki WhatsApp rehberi telefona senkronlanmaz (numaralar telefona gitmez).
- Telefondan **komut çalıştırma varsayılan KAPALI**. Açmak için PC'de `config\api_keys.json` içinde
  `"remote_allow_shell": true` yap. Açıksa her komut telefonda onay ister; ayrıca varsayılan olarak PC'de de onay penceresi çıkar
  (`remote_shell_pc_approval: false` yaparsan yalnızca telefon onayı yeter).

## Güvenlik özeti
Token'sız istek reddedilir, 5 hatalı denemede IP 10 dk kilitlenir · tehlikeli komutlar sunucuda da engellenir ·
her işlem `logs\remote_audit.log` dosyasına yazılır · telefondaki anahtarlar ve hafıza şifreli saklanır ·
PC'den gelen içerik modele "harici veri" olarak verilir.

## Sorun giderme
- *PC'ye ulaşılamadı*: ikisinde de Tailscale açık mı? PC'de JARVIS çalışıyor mu? `ESLESTIR.bat` yönetici olarak çalıştı mı?
- *PC token'ı yanlış*: `--rotate` yaptıysan telefondaki token'ı güncelle.
- Gradle hatası: Android Studio > File > Sync Project with Gradle Files; JDK 17 seçili olsun.
