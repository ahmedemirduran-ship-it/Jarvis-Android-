package com.jarvis.app

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import org.json.JSONObject
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

class MainActivity : Activity(), LiveClient.Listener {

    private val bg = Color.parseColor("#020C0C")
    private val cyan = Color.parseColor("#00D4C0")
    private val orange = Color.parseColor("#FF6600")
    private val textColor = Color.parseColor("#CFEFEA")
    private val dim = Color.parseColor("#4A8A84")

    private lateinit var store: Store
    private lateinit var pc: PcBridge
    private lateinit var tools: ToolRunner
    private lateinit var audio: AudioIO
    private var live: LiveClient? = null

    private val ui = Handler(Looper.getMainLooper())
    private val worker = Executors.newCachedThreadPool()

    @Volatile
    private var active = false
    private var lastSpeaker = ""

    private lateinit var statusView: TextView
    private lateinit var micButton: Button
    private lateinit var logView: TextView
    private lateinit var logScroll: ScrollView
    private lateinit var settingsScroll: ScrollView
    private lateinit var keyField: EditText
    private lateinit var hostField: EditText
    private lateinit var tokenField: EditText
    private lateinit var voiceField: EditText
    private lateinit var modelField: EditText
    private lateinit var bargeBox: CheckBox

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = Store(this)
        pc = PcBridge(store)
        tools = ToolRunner(this, store, pc)
        audio = AudioIO { chunk ->
            val l = live
            if (l != null && l.ready && (store.bargeIn || !audio.isSpeaking)) l.sendAudio(chunk)
        }
        window.statusBarColor = bg
        window.navigationBarColor = bg
        buildUi()
        loadSettingsIntoFields()
        setStatus("Hazır")
        if (store.geminiKey.isBlank()) showSettings(true)
    }

    // ── Arayüz ─────────────────────────────────────────────────────────────
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun label(text: String): TextView = TextView(this).apply {
        this.text = text
        setTextColor(dim)
        textSize = 12f
        setPadding(0, dp(12), 0, dp(2))
    }

    private fun field(hint: String, secret: Boolean = false): EditText = EditText(this).apply {
        this.hint = hint
        setHintTextColor(dim)
        setTextColor(textColor)
        setSingleLine(true)
        inputType = if (secret) InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        else InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
        setBackgroundColor(Color.parseColor("#0A1A1A"))
        setPadding(dp(12), dp(10), dp(12), dp(10))
    }

    private fun flatButton(text: String, color: Int): Button = Button(this).apply {
        this.text = text
        setTextColor(Color.BLACK)
        isAllCaps = true
        background = GradientDrawable().apply {
            cornerRadius = dp(10).toFloat()
            setColor(color)
        }
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
            setPadding(dp(20), dp(36), dp(20), dp(16))
            gravity = Gravity.CENTER_HORIZONTAL
        }

        val logo = ImageView(this).apply { setImageResource(R.drawable.logo) }
        root.addView(logo, LinearLayout.LayoutParams(dp(120), dp(120)))

        root.addView(TextView(this).apply {
            text = "J.A.R.V.I.S"
            setTextColor(cyan)
            textSize = 22f
            typeface = Typeface.MONOSPACE
            gravity = Gravity.CENTER
            letterSpacing = 0.2f
        })

        statusView = TextView(this).apply {
            setTextColor(orange)
            textSize = 13f
            gravity = Gravity.CENTER
            setPadding(0, dp(6), 0, dp(10))
        }
        root.addView(statusView)

        micButton = Button(this).apply {
            text = "BAŞLAT"
            setTextColor(cyan)
            textSize = 15f
            typeface = Typeface.DEFAULT_BOLD
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.parseColor("#04201F"))
                setStroke(dp(3), cyan)
            }
            setOnClickListener { toggle() }
        }
        root.addView(micButton, LinearLayout.LayoutParams(dp(130), dp(130)))

        logView = TextView(this).apply {
            setTextColor(textColor)
            textSize = 13f
            setPadding(dp(4), dp(8), dp(4), dp(8))
        }
        logScroll = ScrollView(this).apply { addView(logView) }
        root.addView(logScroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f).apply {
            topMargin = dp(12)
        })

        // Ayarlar paneli
        val panel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        keyField = field("Gemini API anahtarı", secret = true)
        hostField = field("PC adresi (örn. 100.64.1.2:8765)")
        tokenField = field("PC token'ı", secret = true)
        voiceField = field("Ses (Orus)")
        modelField = field("Model")
        bargeBox = CheckBox(this).apply {
            text = "JARVIS konuşurken mikrofon açık kalsın (yankı olabilir)"
            setTextColor(textColor)
        }
        panel.addView(label("GEMINI API ANAHTARI")); panel.addView(keyField)
        panel.addView(label("BİLGİSAYAR ADRESİ (Tailscale IP:port)")); panel.addView(hostField)
        panel.addView(label("BİLGİSAYAR TOKEN'I (ESLESTIR.bat çıktısı)")); panel.addView(tokenField)
        panel.addView(label("SES")); panel.addView(voiceField)
        panel.addView(label("MODEL")); panel.addView(modelField)
        panel.addView(bargeBox)
        val save = flatButton("KAYDET", cyan).apply { setOnClickListener { saveSettings() } }
        val test = flatButton("PC BAĞLANTISINI DENE", orange).apply { setOnClickListener { testPc() } }
        panel.addView(save, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(14) })
        panel.addView(test, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(8) })
        settingsScroll = ScrollView(this).apply {
            addView(panel)
            visibility = View.GONE
        }
        root.addView(settingsScroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        val settingsButton = Button(this).apply {
            text = "AYARLAR"
            setTextColor(dim)
            setBackgroundColor(Color.TRANSPARENT)
            setOnClickListener { showSettings(settingsScroll.visibility != View.VISIBLE) }
        }
        root.addView(settingsButton)

        setContentView(root)
    }

    private fun showSettings(show: Boolean) {
        settingsScroll.visibility = if (show) View.VISIBLE else View.GONE
        logScroll.visibility = if (show) View.GONE else View.VISIBLE
    }

    private fun loadSettingsIntoFields() {
        keyField.setText(store.geminiKey)
        hostField.setText(store.pcHost)
        tokenField.setText(store.pcToken)
        voiceField.setText(store.voice)
        modelField.setText(store.model)
        bargeBox.isChecked = store.bargeIn
    }

    private fun saveSettings() {
        store.geminiKey = keyField.text.toString()
        store.pcHost = hostField.text.toString()
        store.pcToken = tokenField.text.toString()
        store.voice = voiceField.text.toString()
        store.model = modelField.text.toString()
        store.bargeIn = bargeBox.isChecked
        toast("Kaydedildi.")
        showSettings(false)
    }

    private fun testPc() {
        saveSettingsQuiet()
        toast("PC deneniyor…")
        worker.execute { toast(pc.ping()) }
    }

    private fun saveSettingsQuiet() {
        store.pcHost = hostField.text.toString()
        store.pcToken = tokenField.text.toString()
    }

    private fun toast(msg: String) = runOnUiThread { Toast.makeText(this, msg, Toast.LENGTH_LONG).show() }

    private fun setStatus(text: String) = ui.post { statusView.text = text }

    private fun appendLog(text: String) = ui.post {
        logView.append(text)
        if (logView.text.length > 8000) logView.text = logView.text.takeLast(6000)
        logScroll.post { logScroll.fullScroll(View.FOCUS_DOWN) }
    }

    private fun logSpeaker(who: String, text: String) {
        if (lastSpeaker != who) {
            lastSpeaker = who
            appendLog("\n$who: ")
        }
        appendLog(text)
    }

    /** Araç iş parçacığından çağrılır: telefonda onay penceresi gösterir ve cevabı bekler. */
    fun confirmBlocking(title: String, message: String): Boolean {
        val latch = CountDownLatch(1)
        var result = false
        runOnUiThread {
            AlertDialog.Builder(this)
                .setTitle(title)
                .setMessage(message.take(1500))
                .setCancelable(false)
                .setNegativeButton("REDDET") { _, _ -> latch.countDown() }
                .setPositiveButton("ONAYLA") { _, _ ->
                    result = true
                    latch.countDown()
                }
                .show()
        }
        latch.await(60, TimeUnit.SECONDS)
        return result
    }

    // ── Oturum ─────────────────────────────────────────────────────────────
    private fun toggle() {
        if (active) stopSession("Durduruldu.") else startSession()
    }

    private fun startSession() {
        if (store.geminiKey.isBlank()) {
            toast("Önce Ayarlar'dan Gemini API anahtarını girin.")
            showSettings(true)
            return
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1)
            return
        }
        active = true
        lastSpeaker = ""
        micButton.text = "DURDUR"
        setStatus("Hafıza eşitleniyor…")
        worker.execute {
            if (pc.configured) {
                val remote = pc.fetchMemory()
                if (remote != null) {
                    store.mergeRemote(remote)
                    pc.flushPending()
                    appendLog("\n[PC hafızası eşitlendi]")
                } else {
                    appendLog("\n[PC'ye ulaşılamadı; yerel hafıza kullanılıyor]")
                }
            }
            val instruction = Prompt.build(store, pc.configured)
            val client = LiveClient(store, this)
            live = client
            setStatus("Bağlanıyor…")
            client.connect(instruction, ToolRunner.declarations(pc.configured))
        }
    }

    private fun stopSession(message: String) {
        active = false
        live?.close()
        live = null
        audio.stop()
        ui.post { micButton.text = "BAŞLAT" }
        setStatus(message)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 1 && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            startSession()
        } else {
            toast("Mikrofon izni olmadan sesli sohbet çalışmaz.")
        }
    }

    // ── LiveClient.Listener ────────────────────────────────────────────────
    override fun onReady() {
        ui.post {
            try {
                audio.start()
                setStatus("Dinliyorum")
            } catch (e: Exception) {
                stopSession("Mikrofon hatası: ${e.message}")
            }
        }
    }

    override fun onAudio(pcm: ByteArray) {
        audio.enqueue(pcm)
    }

    override fun onInterrupted() {
        audio.flush()
    }

    override fun onUserText(text: String) = logSpeaker("Sen", text)

    override fun onModelText(text: String) = logSpeaker("JARVIS", text)

    override fun onToolCall(id: String, name: String, args: JSONObject) {
        worker.execute {
            setStatus("Araç: $name")
            appendLog("\n[araç: $name]")
            val result = try {
                tools.run(name, args)
            } catch (e: Exception) {
                "Hata: ${e.javaClass.simpleName}"
            }
            live?.sendToolResponse(id, name, result)
            if (active) setStatus("Dinliyorum")
        }
    }

    override fun onClosed(reason: String) {
        ui.post { if (active) stopSession(reason) }
    }

    override fun onDestroy() {
        super.onDestroy()
        active = false
        live?.close()
        audio.stop()
        worker.shutdownNow()
    }
}
