package com.jarvis.app

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import org.json.JSONArray
import org.json.JSONObject
import java.text.Normalizer
import java.util.Locale

/** Ayarlar ve hafıza. Hepsi şifreli (EncryptedSharedPreferences) saklanır. */
class Store(context: Context) {
    private val prefs: SharedPreferences

    init {
        val masterKey = MasterKey.Builder(context)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()
        prefs = EncryptedSharedPreferences.create(
            context,
            "jarvis_secure",
            masterKey,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    }

    private fun str(key: String, def: String = ""): String = prefs.getString(key, def) ?: def
    private fun put(key: String, value: String) {
        prefs.edit().putString(key, value).apply()
    }

    var geminiKey: String
        get() = str("gemini_key")
        set(v) = put("gemini_key", v.trim())

    var pcHost: String
        get() = str("pc_host")
        set(v) = put("pc_host", v.trim())

    var pcToken: String
        get() = str("pc_token")
        set(v) = put("pc_token", v.trim())

    var voice: String
        get() = str("voice", "Orus")
        set(v) = put("voice", v.trim().ifEmpty { "Orus" })

    var model: String
        get() = str("model", DEFAULT_MODEL)
        set(v) = put("model", v.trim().ifEmpty { DEFAULT_MODEL })

    var bargeIn: Boolean
        get() = prefs.getBoolean("barge_in", false)
        set(v) {
            prefs.edit().putBoolean("barge_in", v).apply()
        }

    // ── Hafıza (PC'dekiyle aynı biçim: {kategori: {anahtar: {"value": ...}}}) ──
    @Synchronized
    fun memory(): JSONObject = try {
        JSONObject(str("memory", "{}"))
    } catch (e: Exception) {
        JSONObject()
    }

    @Synchronized
    private fun saveMemory(o: JSONObject) = put("memory", o.toString())

    @Synchronized
    fun setMemory(category: String, key: String, value: String) {
        val m = memory()
        val bucket = m.optJSONObject(category) ?: JSONObject()
        bucket.put(key, JSONObject().put("value", value))
        m.put(category, bucket)
        saveMemory(m)
    }

    @Synchronized
    fun deleteMemory(matchText: String): String {
        val needle = norm(matchText)
        if (needle.isEmpty()) return "Silinecek ifade boş."
        val m = memory()
        for (cat in m.keys().asSequence().toList()) {
            val bucket = m.optJSONObject(cat) ?: continue
            for (k in bucket.keys().asSequence().toList()) {
                val v = bucket.optJSONObject(k)?.optString("value") ?: bucket.optString(k)
                if (norm(cat).contains(needle) || norm(k).contains(needle) || norm(v).contains(needle)) {
                    bucket.remove(k)
                    if (bucket.length() == 0) m.remove(cat)
                    saveMemory(m)
                    return "$cat/$k silindi."
                }
            }
        }
        return "Eşleşen kayıt bulunamadı."
    }

    /** PC'den gelen hafızayı yerel hafızayla birleştirir (PC değerleri öncelikli). */
    @Synchronized
    fun mergeRemote(remote: JSONObject) {
        val m = memory()
        for (cat in remote.keys().asSequence().toList()) {
            val rb = remote.optJSONObject(cat) ?: continue
            val lb = m.optJSONObject(cat) ?: JSONObject()
            for (k in rb.keys().asSequence().toList()) lb.put(k, rb.get(k))
            m.put(cat, lb)
        }
        saveMemory(m)
    }

    @Synchronized
    fun memoryPromptText(): String {
        val m = memory()
        val lines = ArrayList<String>()
        for (cat in m.keys().asSequence().toList()) {
            val bucket = m.optJSONObject(cat) ?: continue
            for (k in bucket.keys().asSequence().toList()) {
                val v = bucket.optJSONObject(k)?.optString("value") ?: bucket.optString(k)
                lines.add("  $cat/$k: $v")
            }
        }
        return lines.joinToString("\n")
    }

    // ── PC'ye henüz gönderilemeyen hafıza değişiklikleri ──
    @Synchronized
    fun pending(): JSONArray = try {
        JSONArray(str("pending", "[]"))
    } catch (e: Exception) {
        JSONArray()
    }

    @Synchronized
    fun setPending(a: JSONArray) = put("pending", a.toString())

    @Synchronized
    fun addPending(item: JSONObject) {
        val a = pending()
        a.put(item)
        // Sınırsız büyümesin
        val trimmed = JSONArray()
        val start = maxOf(0, a.length() - 50)
        for (i in start until a.length()) trimmed.put(a.get(i))
        setPending(trimmed)
    }

    companion object {
        const val DEFAULT_MODEL = "models/gemini-2.5-flash-native-audio-latest"

        fun norm(s: String): String {
            val lower = s.lowercase(Locale("tr"))
            return Normalizer.normalize(lower, Normalizer.Form.NFD)
                .replace(Regex("\\p{Mn}+"), "")
                .replace('ı', 'i')
                .trim()
        }

        /** Kontrol karakterlerini atar, boşlukları sadeleştirir, uzunluğu sınırlar. */
        fun clean(s: String, limit: Int): String =
            s.filter { !it.isISOControl() }.trim().replace(Regex("\\s+"), " ").take(limit)

        private val INJECTION = Regex(
            "(ignore (all |any )?(previous|prior|above)|önceki (tüm )?(talimat|komut)|system prompt|" +
                "sistem (istemi|talimat)|pc_run_command|shell_run|araç(ları)? çağır)",
            RegexOption.IGNORE_CASE
        )

        /** Hafızaya yazılacak girdi güvenli değilse null. */
        fun sanitizeMemory(category: String, key: String, value: String): Triple<String, String, String>? {
            val c = clean(category, 40).ifEmpty { "notes" }
            val k = clean(key, 80)
            val v = clean(value, 400)
            if (k.isEmpty() || v.isEmpty()) return null
            if (INJECTION.containsMatchIn(k) || INJECTION.containsMatchIn(v)) return null
            return Triple(c, k, v)
        }
    }
}
