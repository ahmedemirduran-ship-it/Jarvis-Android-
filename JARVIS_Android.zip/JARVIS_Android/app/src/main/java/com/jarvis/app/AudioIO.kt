package com.jarvis.app

import android.annotation.SuppressLint
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.media.audiofx.AcousticEchoCanceler
import android.media.audiofx.NoiseSuppressor
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit

/** Mikrofon (16 kHz) yakalama ve hoparlör (24 kHz) çalma. Yankı önleyici (AEC) açılır. */
class AudioIO(private val onChunk: (ByteArray) -> Unit) {
    private var record: AudioRecord? = null
    private var track: AudioTrack? = null
    private var recordThread: Thread? = null
    private var playThread: Thread? = null
    private val playQueue = LinkedBlockingQueue<ByteArray>()

    @Volatile
    private var running = false

    @Volatile
    private var lastWrite = 0L

    /** Model şu an konuşuyor mu (kuyrukta ses var ya da az önce çalındı). */
    val isSpeaking: Boolean
        get() = playQueue.isNotEmpty() || System.currentTimeMillis() - lastWrite < 400

    @SuppressLint("MissingPermission")
    @Synchronized
    fun start() {
        if (running) return
        val inRate = 16000
        val outRate = 24000
        val minIn = AudioRecord.getMinBufferSize(
            inRate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
        )
        val rec = AudioRecord(
            MediaRecorder.AudioSource.VOICE_COMMUNICATION,
            inRate,
            AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT,
            maxOf(minIn, 3200) * 2
        )
        if (rec.state != AudioRecord.STATE_INITIALIZED) {
            rec.release()
            throw IllegalStateException("Mikrofon başlatılamadı (izin verildi mi?).")
        }
        if (AcousticEchoCanceler.isAvailable()) {
            AcousticEchoCanceler.create(rec.audioSessionId)?.enabled = true
        }
        if (NoiseSuppressor.isAvailable()) {
            NoiseSuppressor.create(rec.audioSessionId)?.enabled = true
        }

        val minOut = AudioTrack.getMinBufferSize(
            outRate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT
        )
        val tr = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(outRate)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build()
            )
            .setBufferSizeInBytes(maxOf(minOut * 2, 48000))
            .setTransferMode(AudioTrack.MODE_STREAM)
            .build()

        record = rec
        track = tr
        running = true
        tr.play()
        rec.startRecording()

        recordThread = Thread {
            val buf = ByteArray(3200) // 100 ms
            while (running) {
                val n = rec.read(buf, 0, buf.size)
                if (n > 0) onChunk(buf.copyOf(n)) else if (n < 0) break
            }
        }.also { it.isDaemon = true; it.start() }

        playThread = Thread {
            while (running) {
                val chunk = playQueue.poll(100, TimeUnit.MILLISECONDS) ?: continue
                try {
                    tr.write(chunk, 0, chunk.size)
                    lastWrite = System.currentTimeMillis()
                } catch (e: Exception) {
                    break
                }
            }
        }.also { it.isDaemon = true; it.start() }
    }

    fun enqueue(pcm: ByteArray) {
        if (running) playQueue.offer(pcm)
    }

    /** Model sözü kesildi: bekleyen sesi at. */
    fun flush() {
        playQueue.clear()
        try {
            track?.pause()
            track?.flush()
            track?.play()
        } catch (e: Exception) {
            // yok say
        }
        lastWrite = 0L
    }

    @Synchronized
    fun stop() {
        running = false
        playQueue.clear()
        try { record?.stop() } catch (e: Exception) {}
        try { record?.release() } catch (e: Exception) {}
        try { track?.stop() } catch (e: Exception) {}
        try { track?.release() } catch (e: Exception) {}
        record = null
        track = null
    }
}
