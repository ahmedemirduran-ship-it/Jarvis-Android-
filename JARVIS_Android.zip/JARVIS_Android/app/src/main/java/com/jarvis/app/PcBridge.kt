package com.jarvis.app

import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/** Bilgisayardaki JARVIS ile konuşur (remote_bridge.py). Tüm çağrılar bloklayıcıdır: arka plan iş parçacığında kullanın. */
class PcBridge(private val store: Store) {
    private val client = OkHttpClient.Builder()
        .connectTimeout(4, TimeUnit.SECONDS)
        .readTimeout(25, TimeUnit.SECONDS)
        .writeTimeout(10, TimeUnit.SECONDS)
        .build()

    val configured: Boolean
        get() = store.pcHost.isNotBlank() && store.pcToken.isNotBlank()

    private fun base(): String {
        val h = store.pcHost.trim().trimEnd('/')
        return if (h.startsWith("http://") || h.startsWith("https://")) h else "http://$h"
    }

    private class Reply(val code: Int, val body: JSONObject)

    private fun call(method: String, path: String, body: JSONObject? = null): Reply {
        val builder = Request.Builder()
            .url(base() + path)
            .header("Authorization", "Bearer " + store.pcToken.trim())
        if (method == "GET") {
            builder.get()
        } else {
            val json = (body ?: JSONObject()).toString()
            builder.post(json.toRequestBody("application/json; charset=utf-8".toMediaType()))
        }
        client.newCall(builder.build()).execute().use { resp ->
            val text = resp.body?.string() ?: "{}"
            val obj = try {
                JSONObject(text)
            } catch (e: Exception) {
                JSONObject().put("error", text.take(200))
            }
            return Reply(resp.code, obj)
        }
    }

    private fun describe(r: Reply): String = when (r.code) {
        200 -> r.body.optString("result", "Tamam.")
        401 -> "PC token'ı yanlış. Ayarlardan düzeltin."
        429 -> "PC çok fazla hatalı deneme nedeniyle kilitledi; 10 dakika bekleyin."
        else -> r.body.optString("error", "PC hata verdi (${r.code}).")
    }

    private inline fun safe(block: () -> String): String = try {
        block()
    } catch (e: Exception) {
        "PC'ye ulaşılamadı. Bilgisayar açık mı, Tailscale ikisinde de bağlı mı? (${e.javaClass.simpleName})"
    }

    fun ping(): String = safe {
        if (!configured) {
            "PC ayarları girilmemiş."
        } else {
            val r = call("GET", "/v1/ping")
            if (r.code == 200) {
                "Bağlı: ${r.body.optString("name")} (komut çalıştırma: " +
                    (if (r.body.optBoolean("shell_enabled")) "açık" else "kapalı") + ")"
            } else {
                describe(r)
            }
        }
    }

    fun fetchMemory(): JSONObject? = try {
        if (!configured) null else {
            val r = call("GET", "/v1/memory")
            if (r.code == 200) r.body.optJSONObject("memory") else null
        }
    } catch (e: Exception) {
        null
    }

    /** Başarılıysa true. Başarısızsa değişiklik sıraya alınır. */
    fun pushMemory(category: String, key: String, value: String): Boolean {
        val ok = try {
            configured && call(
                "POST", "/v1/memory",
                JSONObject().put("category", category).put("key", key).put("value", value)
            ).code == 200
        } catch (e: Exception) {
            false
        }
        if (!ok && configured) {
            store.addPending(
                JSONObject().put("op", "set").put("category", category).put("key", key).put("value", value)
            )
        }
        return ok
    }

    fun deleteMemory(matchText: String): String = safe {
        if (!configured) {
            "PC bağlı değil; yalnızca telefondan silindi."
        } else {
            describe(call("POST", "/v1/memory/delete", JSONObject().put("match_text", matchText)))
        }
    }

    /** Çevrimdışıyken biriken hafıza değişikliklerini gönderir. */
    fun flushPending() {
        if (!configured) return
        val pending = store.pending()
        if (pending.length() == 0) return
        val remaining = JSONArray()
        for (i in 0 until pending.length()) {
            val item = pending.getJSONObject(i)
            val sent = try {
                call(
                    "POST", "/v1/memory",
                    JSONObject().put("category", item.optString("category"))
                        .put("key", item.optString("key")).put("value", item.optString("value"))
                ).code == 200
            } catch (e: Exception) {
                false
            }
            if (!sent) remaining.put(item)
        }
        store.setPending(remaining)
    }

    fun openApp(name: String): String = safe {
        describe(call("POST", "/v1/open_app", JSONObject().put("app_name", name)))
    }

    fun findFiles(query: String): String = safe {
        describe(call("POST", "/v1/find_files", JSONObject().put("query", query)))
    }

    fun sysInfo(query: String): String = safe {
        describe(call("POST", "/v1/sys_info", JSONObject().put("query", query)))
    }

    fun shell(command: String, confirmed: Boolean): String = safe {
        describe(call("POST", "/v1/shell", JSONObject().put("command", command).put("confirmed", confirmed)))
    }
}
