package com.jarvis.app

import android.util.Base64
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import okio.ByteString
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/** Gemini Live API (WebSocket) istemcisi. */
class LiveClient(private val store: Store, private val listener: Listener) {

    interface Listener {
        fun onReady()
        fun onAudio(pcm: ByteArray)
        fun onInterrupted()
        fun onUserText(text: String)
        fun onModelText(text: String)
        fun onToolCall(id: String, name: String, args: JSONObject)
        fun onClosed(reason: String)
    }

    private val client = OkHttpClient.Builder()
        .readTimeout(0, TimeUnit.MILLISECONDS)
        .pingInterval(20, TimeUnit.SECONDS)
        .build()

    private var ws: WebSocket? = null

    @Volatile
    var ready = false
        private set

    fun connect(systemInstruction: String, tools: JSONArray) {
        ready = false
        val url = "wss://generativelanguage.googleapis.com/ws/" +
            "google.ai.generativelanguage.v1beta.GenerativeService.BidiGenerateContent" +
            "?key=" + store.geminiKey
        val request = Request.Builder().url(url).build()

        val setup = JSONObject().put(
            "setup", JSONObject()
                .put("model", store.model)
                .put(
                    "generationConfig", JSONObject()
                        .put("responseModalities", JSONArray().put("AUDIO"))
                        .put(
                            "speechConfig", JSONObject().put(
                                "voiceConfig", JSONObject().put(
                                    "prebuiltVoiceConfig", JSONObject().put("voiceName", store.voice)
                                )
                            )
                        )
                )
                .put(
                    "systemInstruction", JSONObject().put(
                        "parts", JSONArray().put(JSONObject().put("text", systemInstruction))
                    )
                )
                .put("tools", JSONArray().put(JSONObject().put("functionDeclarations", tools)))
                .put("inputAudioTranscription", JSONObject())
                .put("outputAudioTranscription", JSONObject())
                .put(
                    "contextWindowCompression",
                    JSONObject().put("slidingWindow", JSONObject())
                )
        )

        ws = client.newWebSocket(request, object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                webSocket.send(setup.toString())
            }

            override fun onMessage(webSocket: WebSocket, text: String) {
                handle(text)
            }

            override fun onMessage(webSocket: WebSocket, bytes: ByteString) {
                handle(bytes.utf8())
            }

            override fun onClosing(webSocket: WebSocket, code: Int, reason: String) {
                webSocket.close(1000, null)
            }

            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                ready = false
                listener.onClosed(if (reason.isNotEmpty()) reason else "Bağlantı kapandı ($code)")
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                ready = false
                val detail = response?.let { "HTTP ${it.code}" } ?: (t.message ?: t.javaClass.simpleName)
                listener.onClosed("Bağlantı hatası: $detail")
            }
        })
    }

    private fun handle(raw: String) {
        val msg = try {
            JSONObject(raw)
        } catch (e: Exception) {
            return
        }

        if (msg.has("setupComplete")) {
            ready = true
            listener.onReady()
        }

        msg.optJSONObject("serverContent")?.let { sc ->
            sc.optJSONObject("modelTurn")?.optJSONArray("parts")?.let { parts ->
                for (i in 0 until parts.length()) {
                    val data = parts.getJSONObject(i).optJSONObject("inlineData")?.optString("data")
                    if (!data.isNullOrEmpty()) {
                        listener.onAudio(Base64.decode(data, Base64.DEFAULT))
                    }
                }
            }
            if (sc.optBoolean("interrupted", false)) listener.onInterrupted()
            sc.optJSONObject("inputTranscription")?.optString("text")?.takeIf { it.isNotEmpty() }
                ?.let { listener.onUserText(it) }
            sc.optJSONObject("outputTranscription")?.optString("text")?.takeIf { it.isNotEmpty() }
                ?.let { listener.onModelText(it) }
        }

        msg.optJSONObject("toolCall")?.optJSONArray("functionCalls")?.let { calls ->
            for (i in 0 until calls.length()) {
                val c = calls.getJSONObject(i)
                listener.onToolCall(
                    c.optString("id"),
                    c.optString("name"),
                    c.optJSONObject("args") ?: JSONObject()
                )
            }
        }
    }

    fun sendAudio(pcm: ByteArray) {
        if (!ready) return
        val b64 = Base64.encodeToString(pcm, Base64.NO_WRAP)
        val m = JSONObject().put(
            "realtimeInput", JSONObject().put(
                "audio", JSONObject().put("data", b64).put("mimeType", "audio/pcm;rate=16000")
            )
        )
        ws?.send(m.toString())
    }

    fun sendToolResponse(id: String, name: String, result: String) {
        val m = JSONObject().put(
            "toolResponse", JSONObject().put(
                "functionResponses", JSONArray().put(
                    JSONObject().put("id", id).put("name", name)
                        .put("response", JSONObject().put("result", result))
                )
            )
        )
        ws?.send(m.toString())
    }

    fun close() {
        ready = false
        try {
            ws?.close(1000, "bitti")
        } catch (e: Exception) {
            // yok say
        }
        ws = null
    }
}
